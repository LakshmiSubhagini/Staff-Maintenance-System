<?php

// Replace with your actual database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "addstf1"; // Updated database name

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Get form data (sanitize and validate for security)
$name = mysqli_real_escape_string($conn, $_POST['name']);
$position = mysqli_real_escape_string($conn, $_POST['position']);
$email = mysqli_real_escape_string($conn, $_POST['email']);

// Create SQL insert query (updated table name)
$sql = "INSERT INTO addstf1(name, position, email) VALUES ('$name', '$position', '$email')";

if (mysqli_query($conn, $sql)) {
  echo "Staff member added successfully!";
} else {
  echo "Error adding staff member: " . mysqli_error($conn);
}

mysqli_close($conn);

?>
